public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.bottom_navigation);
        loadFragment(new ChatFragment()); // default

        bottomNav.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.nav_chat:
                    loadFragment(new ChatFragment());
                    return true;
                case R.id.nav_calls:
                    loadFragment(new CallsFragment());
                    return true;
                case R.id.nav_updates:
                    loadFragment(new UpdatesFragment());
                    return true;
                case R.id.nav_community:
                    loadFragment(new CommunityFragment());
                    return true;
                case R.id.nav_stories:
                    loadFragment(new StoriesFragment());
                    return true;
            }
            return false;
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit();
    }
}

	
<menu xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@+id/nav_chat" android:title="Chat" android:icon="@drawable/ic_chat"/>
    <item android:id="@+id/nav_calls" android:title="Calls" android:icon="@drawable/ic_call"/>
    <item android:id="@+id/nav_updates" android:title="Updates" android:icon="@drawable/ic_updates"/>
    <item android:id="@+id/nav_community" android:title="Community" android:icon="@drawable/ic_community"/>
    <item android:id="@+id/nav_stories" android:title="Stories" android:icon="@drawable/ic_stories"/>
</menu>

public class ChatFragment extends Fragment {
    public ChatFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_chat, container, false);
    }
}

public class RegisterActivity extends AppCompatActivity {
    EditText email, password;
    Button register;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        register = findViewById(R.id.registerBtn);
        mAuth = FirebaseAuth.getInstance();

        register.setOnClickListener(v -> {
            String emailStr = email.getText().toString();
            String passStr = password.getText().toString();

            mAuth.createUserWithEmailAndPassword(emailStr, passStr)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(this, MainActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
        });
    }
}
public class RegisterActivity extends AppCompatActivity {
    EditText email, password;
    Button register;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        register = findViewById(R.id.registerBtn);
        mAuth = FirebaseAuth.getInstance();

        register.setOnClickListener(v -> {
            String emailStr = email.getText().toString();
            String passStr = password.getText().toString();

            mAuth.createUserWithEmailAndPassword(emailStr, passStr)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(this, MainActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
        });
    }
}